a=10
b=10
print("Addition is:",a+b)