#include<iostream.h>
void main()
{
    cout<<"Hello World";
}